export default class FormData {
   constructor (Name, Phone, Email, Message) {
      this.Name = Name,
      this.Phone = Phone,
      this.Email = Email, 
      this.Message = Message
   }
}

